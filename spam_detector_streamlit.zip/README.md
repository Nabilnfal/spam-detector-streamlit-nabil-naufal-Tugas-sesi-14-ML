
# Spam Detector with Streamlit

A simple spam message detection app built with Streamlit.

## How to run
```
streamlit run app.py
```
